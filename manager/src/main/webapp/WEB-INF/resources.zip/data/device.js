var deviceData = [
	{
		"device": "원동기",
		"item": "작동상태(공회전)",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "없음",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "오일누유",
		"part": "실린더 헤드",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "미세누유",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}, {
				"text": "누유",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "오일누유",
		"part": "실러드 블록",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "미세누유",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}, {
				"text": "누유",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "오일 유량 및 오염",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "적정",
				"value": ""
			}, {
				"text": "부족",
				"value": ""
			}, {
				"text": "오염",
				"value": ""
			}, {
				"text": "교환요",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "냉각수누수",
		"part": "실리더 블록",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "미세누유",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "냉각수누수",
		"part": "실러더 헤드/가스켓",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "미세누유",
				"value": ""
			}, {
				"text": "누수",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "냉각수누수",
		"part": "워터펌프",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "미세누유",
				"value": ""
			}, {
				"text": "누수",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "냉각수누수",
		"part": "냉각쿨러(라디에이터)",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "미세누유",
				"value": ""
			}, {
				"text": "누수",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "냉각수누수",
		"part": "냉각수량 및 오염",
		"radioName": "",
		"state": [
			{
				"text": "적정",
				"value": ""
			}, {
				"text": "부족",
				"value": ""
			}, {
				"text": "오염",
				"value": ""
			}, {
				"text": "교환식(부식)",
				"value": ""
			}
		]
	},
	{
		"device": "원동기",
		"item": "고압펌프(커먼레일)",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "양호",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}, {
				"text": "불량",
				"value": ""
			}
		]
	},
	{
		"device": "변속기",
		"item": "자동변속기<br>(A/T)",
		"part": "오일누유",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "미세누유",
				"value": ""
			}, {
				"text": "누유",
				"value": ""
			}
		]
	},
	{
		"device": "변속기",
		"item": "자동변속기<br>(A/T)",
		"part": "오일유량 및 상태",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "적정",
				"value": ""
			}, {
				"text": "부족",
				"value": ""
			}, {
				"text": "과다",
				"value": ""
			}, {
				"text": "오염(희석)",
				"value": ""
			}
		]
	},
	{
		"device": "변속기",
		"item": "자동변속기<br>(A/T)",
		"part": "작동상태(공회전)",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "지연",
				"value": ""
			}, {
				"text": "소음",
				"value": ""
			}, {
				"text": "충격",
				"value": ""
			}
		]
	},
	{
		"device": "동력전달",
		"item": "클러치 어셈블리",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "이상",
				"value": ""
			}, {
				"text": "소음",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "동력전달",
		"item": "등속죠인트",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "고무부트손상",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "동력전달",
		"item": "추진축 및 베어링",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "양호",
				"value": ""
			}, {
				"text": "소음",
				"value": ""
			}, {
				"text": "유격",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "조향",
		"item": "동력조향 작동 오일 누유",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "미세누유",
				"value": ""
			}, {
				"text": "누유",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "조향",
		"item": "작동상태",
		"part": "스티어링 기어",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "소음",
				"value": ""
			}, {
				"text": "유격",
				"value": ""
			}
		]
	},
	{
		"device": "조향",
		"item": "작동상태",
		"part": "스티어링 펌프",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "양호",
				"value": ""
			}, {
				"text": "소음",
				"value": ""
			}
		]
	},
	{
		"device": "조향",
		"item": "작동상태",
		"part": "타이로드엔드 및 볼 죠인트",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "제동",
		"item": "브레이크 오일 유량상태",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "적정",
				"value": ""
			}, {
				"text": "부족",
				"value": ""
			}, {
				"text": "오염",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "제동",
		"item": "브레이크 오일 누유",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "누유",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "제동",
		"item": "배력장치 상태",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "전기",
		"item": "발전기 출력",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "전기",
		"item": "시동 모터",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "전기",
		"item": "와이퍼 모터 기능",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "전기",
		"item": "실내송품 모터",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "소음",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "전기",
		"item": "라디에이터 팬 뫁",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "소음",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "기타",
		"item": "연료노출(LPG가스포함)",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "없음",
				"value": ""
			}, {
				"text": "있음",
				"value": ""
			}
		]
	},
	{
		"device": "기타",
		"item": "윈도우 모터 작동",
		"part": "",
		"radioName": "",
		"state": [
			{
				"text": "양호",
				"value": ""
			}, {
				"text": "소음",
				"value": ""
			}, {
				"text": "정비요",
				"value": ""
			}
		]
	},
	{
		"device": "",
		"item": "",
		"part": "",
		"radioName": "test",
		"other": "특기사항 및 점검자 의견",
		"input": "textarea"
	}
];