(function($) {
	$.fn.tablesorter = function() {
		return this.each(function() {
			var $table = $(this),
				$th = $table.find('thead th.header');

			$th.on('click.sort keypress.sort', function() {
				var $sort = $(this),
					_type = null;

				$sort.siblings('.header').removeAttr('data-sort');

				if($sort.attr('data-sort') == 'desc' || !$sort.attr('data-sort')) {
					_type = 'asc';
				} else if($sort.attr('data-sort') == 'asc') {
					_type = 'desc';
				}

				$sort.attr('data-sort', _type);
				$sort.trigger('sort', [_type]);
			}).attr('tabindex', 0);
		});
	};
})(jQuery);